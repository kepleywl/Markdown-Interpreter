
*   This is the first list item.
*   Here's the second list item.

    > A blockquote would look great below the second list item.

*   And here's the third list item.



*   This is the first list item.
*   *Here's the second list item.*

    I need to add another paragraph below the second list item.

*   And here's the third list item.

