
1. *First* Item 
2. Second Item
    1. **Sublist**
    2. ***Emphasized sublist***
3. Third item
    - Unordered List within ordered list
    - Second Item



* Unordered List
    * Unordered Sublist
    * **Bold sublist item**
* *Unordered List Italic Item*











